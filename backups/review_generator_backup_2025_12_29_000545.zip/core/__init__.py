"""Core functionality package."""

